package transformers;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mule.api.MuleMessage;
import org.mule.transformer.AbstractMessageTransformer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

import java.io.StringWriter;

public class Json2XML2 extends AbstractMessageTransformer {

    @Override
    public Object transformMessage(MuleMessage muleMessage, String outputEncoding){
        String json = (String) muleMessage.getPayload();

        // Parsear el JSON
        JSONObject jsonObject = new JSONObject(json);
        JSONArray actosEvaluacion = jsonObject.getJSONArray("actos-evaluacion");

        // Crear el documento XML
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder;
        Document document;

        try {
            documentBuilder = documentFactory.newDocumentBuilder();
            document = documentBuilder.newDocument();

            // Crear el elemento raíz <notas>
            Element root = document.createElement("notas");
            document.appendChild(root);

            // Procesar los actos de evaluación
            for (int i = 0; i < actosEvaluacion.length(); i++) {
                JSONObject acto = actosEvaluacion.getJSONObject(i);
                String asignatura = acto.getString("asignatura");
                String nombre = acto.getString("nombre");
                JSONArray notas = acto.getJSONArray("notas");

                // Iterar por cada nota y generar un <actoEvaluacion>
                for (int j = 0; j < notas.length(); j++) {
                    String[] notaDetalle = notas.getString(j).split(":");
                    String dni = notaDetalle[0];
                    String nota = notaDetalle[1];

                    // Crear elemento <actoEvaluacion>
                    Element actoEvaluacionElement = document.createElement("actoEvaluacion");

                    // Crear subelementos
                    Element asignaturaElement = document.createElement("asignatura");
                    Text asignaturaText = document.createTextNode(asignatura);
                    asignaturaElement.appendChild(asignaturaText);
                    actoEvaluacionElement.appendChild(asignaturaElement);

                    Element nombreElement = document.createElement("nombre");
                    Text nombreText = document.createTextNode(nombre);
                    nombreElement.appendChild(nombreText);
                    actoEvaluacionElement.appendChild(nombreElement);

                    Element alumnoElement = document.createElement("alumno");
                    alumnoElement.setAttribute("dni", dni);
                    Text notaText = document.createTextNode(nota);
                    alumnoElement.appendChild(notaText);
                    actoEvaluacionElement.appendChild(alumnoElement);

                    // Añadir <actoEvaluacion> al root
                    root.appendChild(actoEvaluacionElement);
                }
            }

            // Convertir el documento XML a String
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource domSource = new DOMSource(document);
            StringWriter writer = new StringWriter();
            StreamResult streamResult = new StreamResult(writer);

            transformer.transform(domSource, streamResult);

            // Retornar el XML como String
            return writer.toString();

        } catch (ParserConfigurationException e) {
            throw new RuntimeException("Error al configurar el parser de XML", e);
        } catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
    }
}
